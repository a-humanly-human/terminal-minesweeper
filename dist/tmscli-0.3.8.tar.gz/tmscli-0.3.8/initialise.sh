source .venv/scripts/activate.bat
alias upgr='pip install --upgrade tmscli'
chmod +x ./update.sh
alias update='./update.sh'
